from setuptools import setup

setup(

	name="paquetecalculos",

	version="1.0",

	description="Paquete de redondeo y potencia",

	author="Eric",

	author_email="emarquez@bcb.com.mx",

	url="wwww.emarquez.8m.net",

	packages=["calculos","calculos.redondeo_potencia"]

	)
